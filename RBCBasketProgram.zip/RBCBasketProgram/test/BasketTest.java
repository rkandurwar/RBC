/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

import org.junit.Assert;

import com.rbc.biz.factory.BasketFactory;
import com.rbc.biz.service.IInventoryServices;
import com.rbc.biz.service.impl.Basket;
import com.rbc.biz.service.impl.InventoryService;
import com.rbc.shared.constants.Item;

/**
 *
 * @author RKandurwar
 */
public class BasketTest extends TestCase{
    private static Basket userBasket = null;
    private static IInventoryServices service = null;
    
    public BasketTest(final String testCase){
    	super(testCase);
    }
    /**
     * This Block initializes the Inventory of fruits
     */
    static{
    	 userBasket = BasketFactory.createBasket();
         service = InventoryService.getInventoryService();
         /**
          *  Preparing Inventory
          * 
          */
         service.addToInventory(Item.APPLE, 10, 2.0);
         service.addToInventory(Item.BANANA, 10, 2.0);
         service.addToInventory(Item.LEMON, 10, 2.0);
         service.addToInventory(Item.ORANGE, 10, 2.0);
         service.addToInventory(Item.PEACH, 10, 2.0);
    }
    public BasketTest() {
    }
    
    public void testAddtoBasket(){
        try{
            userBasket.addItem(Item.APPLE, 2);
            userBasket.addItem(Item.BANANA, 2);
            Assert.assertTrue("Item Added To User Basket..", true);
        }catch(Exception e){
        	Assert.fail("Error While Adding Item To Basket...");
        }
    }
    public void testAddItemTwice(){
    	try{
            userBasket.addItem(Item.APPLE, 2);
            Assert.assertTrue("Item Added To User Basket..", true);
        }catch(Exception e){
        	Assert.fail("Error While Adding Item To Basket...");
        }
    }
    public void testRemoveItemFromBasket(){
    	try{
    		Assert.assertTrue("Item Failed To Remove From Basket..", userBasket.removeItem(Item.APPLE));
    	}catch(Exception e){
    		Assert.fail("Error While Removing An Item From Basket...");
    	}
    }
    public void testRemoveNonExistItemFromBasket(){
    	try{
    		userBasket.removeItem(Item.LEMON);
    		Assert.fail("Exception Was Expected...");
    	}catch(Exception e){
    		Assert.assertTrue(true);
    	}
    }
    public void testItemsTotal(){
    	Double total = userBasket.getTotalCost();
    	Assert.assertEquals(new Double(4.0), total);
    }
    public void testOutOfStock(){
    	try{
    		userBasket.addItem(Item.PEACH, 1000);
    		Assert.fail("Out Of Stock Was Expected.....");
    	}catch(Exception e){
    		Assert.assertTrue(true);
    	}
    }
    
    public static TestSuite suite(){
    	TestSuite suite = new TestSuite();
    	suite.addTest(new BasketTest("testAddtoBasket"));
    	suite.addTest(new BasketTest("testAddItemTwice"));
    	suite.addTest(new BasketTest("testRemoveItemFromBasket"));
    	suite.addTest(new BasketTest("testRemoveNonExistItemFromBasket"));
    	suite.addTest(new BasketTest("testItemsTotal"));
    	suite.addTest(new BasketTest("testOutOfStock"));
    	return suite;
    }
    
    public static void main(String[] args) {
		TestRunner.run(BasketTest.suite());
	}
}