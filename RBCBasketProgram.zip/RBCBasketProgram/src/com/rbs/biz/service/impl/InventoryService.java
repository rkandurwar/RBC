package com.rbs.biz.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

import com.rbc.shared.ItemDetails;
import com.rbc.shared.Itemized;
import com.rbc.shared.constants.Item;
import com.rbs.biz.service.IInventoryServices;

/**
 * This is an Implementation of {@link IInventoryServices}
 * @author RKandurwar
 */
public class InventoryService implements IInventoryServices{
    private Map<Item, Itemized> items = null;
    /**
     * To handle concurrency
     */
    private ReentrantLock LOCK = null;
    
    private static final IInventoryServices service = new InventoryService();
    
    /**
     * 
     */
    private InventoryService() {
        items = new HashMap<Item, Itemized>();
        LOCK = new ReentrantLock();
    }
    
    public static IInventoryServices getInventoryService(){
        return service;
    }
    
    @Override
    public void addToInventory(Item item, Integer quantity, Double prize) {
        Itemized i = new Itemized();
        i.setItem(item);
        i.setQuantity(quantity);
        i.setPrize(prize);
        this.items.put(item, i);
    }

    @Override
    public void removeFromInventory(Item item) {
        try{
            LOCK.lock();
            this.items.remove(item);
        }finally{
            LOCK.unlock();
        }
    }

    @Override
    public void updateInventory(Item item, Integer quantity, Double prize) {
        try{
            LOCK.lock();
            Itemized itemized = this.items.remove(item);
        if(itemized == null){
            itemized = new Itemized();
        }
        itemized.setItem(item);
        itemized.setPrize(prize);
        itemized.setQuantity(quantity);
        this.items.put(item, itemized);
        }finally{
            LOCK.unlock();
        }
    }

    @Override
    public List<ItemDetails> getItems() {
        List<ItemDetails> i = new ArrayList<ItemDetails>();
        for(Map.Entry<Item,Itemized> entry : this.items.entrySet()){
            i.add(entry.getValue());
        }
        return Collections.unmodifiableList(i);
    }
    
    @Override
    public ItemDetails getItemized(final Item item) {
        return this.items.get(item);
    }
    
}
