package com.rbs.biz.service.impl;

import com.rbc.shared.ItemDetails;
import com.rbc.shared.constants.Item;
import com.rbs.biz.service.IInventoryServices;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

/**
 * This class holds the business logic for managing the Basket with user Items
 * @author RKandurwar
 */
public class Basket {
    private IInventoryServices inventoryService = null;
    private Map<Item, Integer> userItems = new HashMap<Item, Integer>();
    private ReentrantLock LOCK = new ReentrantLock();
    
    /**
     * Adds an item to the Basket. This is a Threadsafe method
     * @param item - {@link Item} to add to Basket
     * @param quantity
     * @throws Exception if {@link Item} goes Out Of Stock
     */
    public void addItem(final Item item, final Integer quantity)throws Exception{
    	ItemDetails itemized = this.inventoryService.getItemized(item);
        try{
        	LOCK.lock();
        	if(itemized.getQuantity() < quantity){
        		throw new Exception("Item is Out Of Stock..");
        	}
            Integer q = this.userItems.get(item);
            if(q != null){
                q+=quantity;
            }else{
                q = quantity;
            }
            this.userItems.put(item, q);
        }finally{
            this.inventoryService.updateInventory(item, itemized.getQuantity()-quantity, itemized.getPrize());
            LOCK.unlock();
        }
    }
    /**
     * Remove {@link Item} from Basket. This is a Threadsafe method 
     * @param item - {@link Item} to remove from Basket
     * @return - true if Successfully removed from Basket
     * @throws Exception - if Item not available in Basket
     */
    public boolean removeItem(final Item item) throws Exception{
        Integer i = 0;
        try{
            LOCK.lock();
            i = this.userItems.remove(item);
            if(i != null){
                return true;
            }
            throw new Exception(item+" Not Found In Your Basket..");
        }finally{
            ItemDetails itemized = this.inventoryService.getItemized(item);
            this.inventoryService.updateInventory(item, itemized.getQuantity()+i, itemized.getPrize());
            LOCK.unlock();
        }
    }
    /**
     * Calculate the total cost of {@link Item} in Basket. This is a Threadsafe method
     * @return {@link Double}
     */
    public Double getTotalCost(){
        Double total = 0.0;
        try{
            LOCK.lock();
            for(Map.Entry<Item,Integer> entry : this.userItems.entrySet()){
                total+=this.inventoryService.getItemized(entry.getKey()).getPrize()*entry.getValue();
            }
        }finally{
            LOCK.unlock();
        }
        return total;
    }
    
    public void setInventoryService(IInventoryServices inventoryService) {
        this.inventoryService = inventoryService;
    }
}
