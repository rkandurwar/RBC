package com.rbc.shared;

import com.rbc.shared.constants.Item;

/**
 * This contract make sure that item will have these methods
 * @author RKandurwar
 */
public interface ItemDetails {
	/**
	 * Returns the Prize of an {@link Item}
	 * @return {@link Double}
	 */
    public Double getPrize();
    /**
     * Item available in Inventory
     * @return {@link Item}
     */
    public Item getItem();
    
    /**
     * Number of pices available in Inventory
     * @return {@link Integer}
     */
    public Integer getQuantity();
}
