/**
 * This is an implementation of {@link ItemDetails}
 */
package com.rbc.shared;

import com.rbc.shared.constants.Item;

public class Itemized implements ItemDetails{
	private Item item = null;
    private Integer quantity = 0;
    private Double prize = 0.0;

    @Override
    public Double getPrize() {
        return prize;
    }

    public void setPrize(Double prize) {
        this.prize = prize;
    }
    @Override
    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }
    @Override
    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}
