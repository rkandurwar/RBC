package com.rbc.shared.constants;


/**
 * list of Items, user can choose to add one or more item to his {@link BasketFactory}-> createBasket()
 * @author RKandurwar
 */
public enum Item {
    BANANA, ORANGE, APPLE, LEMON, PEACH
}
