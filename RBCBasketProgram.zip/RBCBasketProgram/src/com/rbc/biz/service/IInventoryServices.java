/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rbc.biz.service;

import java.util.List;

import com.rbc.shared.ItemDetails;
import com.rbc.shared.constants.Item;

/**
 * This contract makes sure that Inventory of fruits is well managed
 * @author RKandurwar
 */
public interface IInventoryServices {
	/**
	 * Adds an {@link Item} to an Inventory
	 * @param item - {@link Item} to be added in Inventory
	 * @param quantity - {@link Integer} number of pices available in inventory
	 * @param prize - {@link Double} prize of an single {@link Item}
	 */
    public void addToInventory(final Item item, final Integer quantity, final Double prize);
    /**
     * Removes an item from Inventory
     * @param item - {@link Item}
     */
    public void removeFromInventory(final Item item) ;
    /**
     * Update the {@link Item} in Inventory, if {@link Item} not exist in inventory then it will be added
     * else existing item wll be updated
     * @param item - {@link Item} to be updated/added in Inventory
     * @param quantity - {@link Integer} number of pices to be updated/added in inventory
     * @param prize - {@link Double} prize of an single {@link Item}
     */
    public void updateInventory(final Item item, final Integer quantity, final Double prize);
    /**
     * Returns a inventory List of {@link ItemDetails} 
     * @return - {@link ItemDetails}
     */
    public List<ItemDetails> getItems();
    /**
     * Return an {@link ItemDetails} of an {@link Item}
     * @param item - {@link Item}
     * @return {@link ItemDetails}
     */
    public ItemDetails getItemized(final Item item);
}
