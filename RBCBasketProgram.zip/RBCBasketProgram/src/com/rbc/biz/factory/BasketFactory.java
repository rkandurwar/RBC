package com.rbc.biz.factory;

import com.rbc.biz.service.IInventoryServices;
import com.rbc.biz.service.impl.Basket;
import com.rbc.biz.service.impl.InventoryService;

/**
 * This is a Factory class to create an Empty {@link Basket} for the user
 * it also set services to manage Inventory
 * @author RKandurwar
 */
public final class BasketFactory {
    
	/**
	 * Instantiate a new instance of {@link Basket}, each user will have his own basket
	 * @return {@link Basket}
	 */
    public static Basket createBasket(){
        IInventoryServices inventoryService = InventoryService.getInventoryService();
        Basket basket = new Basket();
        basket.setInventoryService(inventoryService);
        return basket;
    }
}
